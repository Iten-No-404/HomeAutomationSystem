rm -rf work/*
cp variables/*  work/
mkdir work/LOGs

